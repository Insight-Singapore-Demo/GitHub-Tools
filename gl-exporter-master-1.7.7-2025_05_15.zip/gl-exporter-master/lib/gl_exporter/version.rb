class GlExporter
  VERSION = "1.7.7".freeze
end
